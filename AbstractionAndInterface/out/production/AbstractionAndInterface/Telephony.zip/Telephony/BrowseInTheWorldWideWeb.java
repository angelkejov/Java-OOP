package Telephony;

public interface BrowseInTheWorldWideWeb {
    String Browsing(String site);
}
