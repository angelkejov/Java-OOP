package Telephony;

public interface Callable {
    String call(String numbers);
}
