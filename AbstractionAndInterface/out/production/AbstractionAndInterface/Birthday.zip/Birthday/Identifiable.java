package Birthday;

public interface Identifiable {
    String getId();
}
