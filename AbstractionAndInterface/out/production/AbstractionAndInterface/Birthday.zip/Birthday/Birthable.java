package Birthday;

public interface Birthable {
    String getBirthDate();
}
