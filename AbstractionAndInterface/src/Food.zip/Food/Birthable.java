package Food;

public interface Birthable {
    String getBirthDate();
}
