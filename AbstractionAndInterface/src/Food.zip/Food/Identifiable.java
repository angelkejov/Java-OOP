package Food;

public interface Identifiable {
    String getId();
}
