package Celebration;

public interface Identifiable {
    String getId();
}
