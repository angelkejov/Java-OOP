package Celebration;

public interface Birthable {
    String getBirthDate();
}
