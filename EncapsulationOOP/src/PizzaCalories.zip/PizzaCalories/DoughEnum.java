package PizzaCalories;

public enum DoughEnum {

    WHITE,
    WHOLEGRAIN,
    CRISPY,
    CHEWY,
    HOMEMADE;
}
