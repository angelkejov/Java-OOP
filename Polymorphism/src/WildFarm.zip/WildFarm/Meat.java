package WildFarm;

public class Meat extends Food {
    public Meat(int quality) {
        super(quality);
    }
}
