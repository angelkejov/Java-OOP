package WildFarm;

public class Vegetable extends Food {
    public Vegetable(int quality) {
        super(quality);
    }
}
