package VehiclesExtension;

public class Bus extends VehicleImpl {

    public Bus(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption);
    }

    public void isFuelIsNegative(double fuelQuantity) {
        if (fuelQuantity < 0) {
            System.out.println("Fuel must be a positive number");
        }
    }
}
