package garage;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class GarageTests {
    List<Car> cars;

    @Before
    public void prepare() {
        Car car = new Car("kur", 1000, 500);
        cars = new ArrayList<>();
        cars.add(car);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddCarShouldThrowExceptionWhenNull() {
        Garage garage = new Garage();
        garage.addCar(null);
    }

    @Test
    public void testAddCarSuccesfully() {
        Garage garage = new Garage();
        garage.addCar(new Car("test_brand", 10, 150.8));
    }

    @Test
    public void testGetMostExpensiveCar() {
        Garage garage = new Garage();
        Car car = new Car("Toyota", 300, 1500.99);
        Car car1 = new Car("Nissan", 400, 1200.99);
        garage.addCar(car);
        garage.addCar(car1);
        Assert.assertEquals(car, garage.getTheMostExpensiveCar());
    }

    @Test
    public void testFindAllCarsByBrand() {
        Garage garage = new Garage();
        Car car = new Car("kur", 300, 1500.99);
        garage.addCar(car);
        Assert.assertEquals(car, garage.findAllCarsByBrand(cars.get(0).toString()));
    }

    @Test
    public void testFindAllCarsWithSpeedAbove() {
        Garage garage = new Garage();
        Car car = new Car("kur", 300, 1500.99);
        int speed = 100;
        garage.addCar(car);
        Assert.assertEquals(car, garage.findAllCarsWithMaxSpeedAbove(speed));
    }
}