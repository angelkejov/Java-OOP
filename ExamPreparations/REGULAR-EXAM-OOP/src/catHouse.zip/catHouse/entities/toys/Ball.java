package catHouse.entities.toys;

public class Ball extends BaseToy {
    private static final int SOFTNESS = 1;
    private static final  double PRICE = 10;

    public Ball() {
        super(SOFTNESS, PRICE);
    }
}
