package glacialExpedition.models.suitcases;

import java.util.Collection;

public interface Suitcase {
    Collection<String> getExhibits();
}
