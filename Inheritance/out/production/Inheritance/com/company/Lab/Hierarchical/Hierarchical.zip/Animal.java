package Inheritance.FirstAndSecondTask.Hierarchical;

public class Animal {

    public void eat() {
        System.out.println("eating...");
    }
}
